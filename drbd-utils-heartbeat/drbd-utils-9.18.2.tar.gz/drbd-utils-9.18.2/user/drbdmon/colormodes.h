#ifndef COLORMODES_H
#define COLORMODES_H



enum class color_mode : uint8_t
{
    BASIC,
    EXTENDED
};

#endif /* COLORMODES_H */
