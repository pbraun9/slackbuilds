#ifndef COMPARATORS_H
#define	COMPARATORS_H

#include <string>

namespace comparators
{
    int compare_string(const std::string* key_ptr, const std::string* other_ptr);
}

#endif	/* COMPARATORS_H */
