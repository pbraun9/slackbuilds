/* automatically generated. DO NOT EDIT. */
#define GITHASH "bd7a08c4ec9cad113c4e5ad448a15c8900a67b68"
#define GITDIFF ""
