PythonExtensions
----------------

.. cmake-module:: ../../skbuild/resources/cmake/FindPythonExtensions.cmake

.. cmake-module:: ../../skbuild/resources/cmake/UsePythonExtensions.cmake
