from skbuild import setup

setup(
    name='hello',
    version='1.2.3',
    author='John Doe',
    author_email='test@example.com',
    url='https://example.com',
    include_package_data=True,
)
