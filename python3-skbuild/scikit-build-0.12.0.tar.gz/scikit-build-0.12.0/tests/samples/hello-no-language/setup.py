from skbuild import setup

setup(
    name="hello_no_language",
    version="1.2.3",
    description="a minimal example package",
    author='The scikit-build team',
    license="MIT"
)
