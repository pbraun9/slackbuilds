
if __name__ == "__main__":
    from . import _hello as hello
    hello.hello("World")
