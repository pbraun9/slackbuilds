
if __name__ == "__main__":
    from . import hello
    hello.hello("World")
