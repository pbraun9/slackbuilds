def hello(msg):
    print(msg)
